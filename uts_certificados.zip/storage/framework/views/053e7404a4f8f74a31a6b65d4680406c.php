<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <title>Registro - Uts Certificados</title>

   <!-- Font Icon -->
   <link rel="stylesheet" href="<?php echo e(asset('fonts/material-icon/css/material-design-iconic-font.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('vendor/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
   <!-- Main css -->
   <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

   <?php if(config('adminlte.google_fonts.allowed', true)): ?>
      <link rel="stylesheet"
         href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
   <?php endif; ?>

</head>

<body>
    <?php echo $__env->yieldContent('body'); ?>

    <?php echo $__env->yieldContent('auth_js'); ?>
</body>

</html>
<?php /**PATH D:\laragon\www\uts_certificados\resources\views/vendor/adminlte/auth/layout/master.blade.php ENDPATH**/ ?>