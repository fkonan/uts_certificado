<?php $__env->startSection('title', 'Mis Solicitudes'); ?>

<?php $__env->startSection('adminlte_css'); ?>
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
   <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.22.3/dist/bootstrap-table.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_header'); ?>
   <h1>Mis solicitudes</h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <div class="card">
      <div class="card-header">
         <div class="row">
            <div class="col">
               <h5 class="mb-0">Listado de solicitud de certificados</h5>
            </div>
            <div class="col text-right">
               <a href="<?php echo e(route('solicitudes.create')); ?>" class="btn btn-primary btn-sm">Nueva solicitud</a>
            </div>
         </div>
      </div>
      <div class="card-body ">
         <table id="table" class="table table-sm table-hover" data-search="true">
            <thead>
               <tr class="bg-success">
                  <th data-sortable="true" data-field="datos.certificados.tipo_certificado">Certificado solicitado</th>
                  <th data-sortable="true" data-field="estado">Estado de la solicitud</th>
                  <th data-field="created_at">Fecha de la solicitud</th>
                  <th data-field="observaciones">Observaciones</th>
                  <th data-field="ruta">Certificado</th>
               </tr>
            </thead>
            <tbody>
               <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php $__currentLoopData = $item->certificados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certificado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                        <td><?php echo e($certificado->tipo_certificado); ?></td>
                        <td><?php echo e($certificado->pivot->estado); ?></td>
                        <td><?php echo e($item->created_at); ?></td>
                        <td><?php echo e($certificado->pivot->observaciones); ?></td>
                        <td>
                           <?php if($certificado->pivot->ruta): ?>
                              <a href="<?php echo e(asset(Storage::url($certificado->pivot->ruta))); ?>" target="_blank"><i
                                    class="fas fa-file-pdf fa-lg text-danger"></i> Descargar</a>
                           <?php else: ?>
                              <i class="fas fa-file fa-lg text-muted"></i>
                           <?php endif; ?>
                        </td>
                     </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
         </table>
      </div>
   </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('adminlte_js'); ?>
   <script src="https://unpkg.com/bootstrap-table@1.22.3/dist/bootstrap-table.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\uts_certificados\resources\views/solicitudes/index.blade.php ENDPATH**/ ?>