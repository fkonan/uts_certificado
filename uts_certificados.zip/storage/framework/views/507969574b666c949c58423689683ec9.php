<?php $__env->startSection('body'); ?>

   <?php ($login_url = View::getSection('login_url') ?? config('adminlte.login_url', 'login')); ?>
   <?php ($register_url = View::getSection('register_url') ?? config('adminlte.register_url', 'register')); ?>
   <?php ($password_reset_url = View::getSection('password_reset_url') ?? config('adminlte.password_reset_url', 'password/reset')); ?>

   <?php if(config('adminlte.use_route_url', false)): ?>
      <?php ($login_url = $login_url ? route($login_url) : ''); ?>
      <?php ($register_url = $register_url ? route($register_url) : ''); ?>
      <?php ($password_reset_url = $password_reset_url ? route($password_reset_url) : ''); ?>
   <?php else: ?>
      <?php ($login_url = $login_url ? url($login_url) : ''); ?>
      <?php ($register_url = $register_url ? url($register_url) : ''); ?>
      <?php ($password_reset_url = $password_reset_url ? url($password_reset_url) : ''); ?>
   <?php endif; ?>

   <div class="main">
      <!-- Sing in  Form -->
      <section class="sign-in">
         <div class="container">
            <div class="signin-content">
               <div class="signin-image">
                  <figure><img src="<?php echo e(asset('images/signin-image.jpg')); ?>" alt="sing up image"></figure>
                  <a href="/register" class="signup-image-link">¿No tienes cuenta? Registrate</a>
               </div>

               <div class="signin-form">
                  <h2 class="form-title">Iniciar Sesión</h2>
                  <form method="POST" action="<?php echo e($login_url); ?>" class="register-form" id="login-form">
                     <?php echo csrf_field(); ?>
                     <div class="form-group">
                        <label for="email"><i class="zmdi zmdi-email material-icons-name"></i></label>
                        <input type="text" name="email"class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('email')); ?>" placeholder="Correo eletrónico" autofocus>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                           </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>

                     <div class="form-group">
                        <label for="password"><i class="zmdi zmdi-lock material-icons-name"></i></label>
                        <input type="password" name="password" id="password" placeholder="Contraseña" />
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                           <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                           </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                     <div class="icheck-primary">
                        <input type="checkbox" name="remember" id="remember" />
                        <label for="remember" class="label-agree-term">Recordar sesión</label>
                     </div>
                     <div class="form-group form-button">
                        <input type="submit" name="signin" id="signin" class="form-submit" value="Iniciar sesión" />
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </section>
   </div>
<?php $__env->startSection('auth_js'); ?>
   <!-- JS -->
   <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
   <script src="<?php echo e(asset('js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

</html>

<?php echo $__env->make('adminlte::auth.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\uts_certificados\resources\views/vendor/adminlte/auth/login.blade.php ENDPATH**/ ?>