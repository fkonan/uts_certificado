# uts_certificado
Aplicacion para crear solicitudes y generación de certificados estudiantiles
